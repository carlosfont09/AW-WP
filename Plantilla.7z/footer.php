<footer class="main-footer">
		<div class="container">
			<div class="f_left">
				<p>&copy; 2019- Carlos Company</p>
			</div>
			<div class="f_right">
			
			</div>

		</div>
	</footer>
	<?php wp_footer(); ?>
</body>
</html>